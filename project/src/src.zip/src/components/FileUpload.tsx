import React, { useCallback, useState } from 'react';
import { Upload, FileText, AlertCircle } from 'lucide-react';

interface FileUploadProps {
  onFileSelect: (file: File) => void;
}

const FileUpload: React.FC<FileUploadProps> = ({ onFileSelect }) => {
  const [dragOver, setDragOver] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleDragOver = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    setDragOver(true);
  }, []);

  const handleDragLeave = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    setDragOver(false);
  }, []);

  const handleDrop = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    setDragOver(false);
    setError(null);

    const files = Array.from(e.dataTransfer.files);
    const pdfFile = files.find(file => file.type === 'application/pdf');

    if (pdfFile) {
      onFileSelect(pdfFile);
    } else {
      setError('Please select a PDF file');
    }
  }, [onFileSelect]);

  const handleFileSelect = useCallback((e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    setError(null);

    if (file) {
      if (file.type === 'application/pdf') {
        onFileSelect(file);
      } else {
        setError('Please select a PDF file');
      }
    }
  }, [onFileSelect]);

  return (
    <div className="w-full max-w-2xl mx-auto p-8">
      <div
        className={`relative border-2 border-dashed rounded-xl p-12 text-center transition-all duration-300 ${
          dragOver
            ? 'border-blue-500 bg-blue-50'
            : 'border-gray-300 hover:border-gray-400'
        }`}
        onDragOver={handleDragOver}
        onDragLeave={handleDragLeave}
        onDrop={handleDrop}
      >
        <div className="flex flex-col items-center space-y-6">
          <div className="relative">
            <div className="bg-blue-100 p-6 rounded-full">
              <FileText className="h-12 w-12 text-blue-600" />
            </div>
            <div className="absolute -top-2 -right-2 bg-gradient-to-r from-purple-600 to-pink-600 p-2 rounded-full">
              <Upload className="h-5 w-5 text-white" />
            </div>
          </div>
          
          <div className="space-y-2">
            <h3 className="text-xl font-semibold text-gray-900">
              Upload your PDF document
            </h3>
            <p className="text-gray-600">
              Drag and drop your PDF file here, or click to browse
            </p>
          </div>
          
          <div className="flex items-center space-x-4">
            <label className="bg-blue-600 text-white px-6 py-3 rounded-lg hover:bg-blue-700 transition-colors cursor-pointer">
              <input
                type="file"
                accept=".pdf"
                onChange={handleFileSelect}
                className="hidden"
              />
              Choose PDF File
            </label>
            <span className="text-sm text-gray-500">
              or drag and drop
            </span>
          </div>
          
          {error && (
            <div className="flex items-center space-x-2 text-red-600 bg-red-50 px-4 py-2 rounded-lg">
              <AlertCircle className="h-4 w-4" />
              <span className="text-sm">{error}</span>
            </div>
          )}
        </div>
      </div>
      
      <div className="mt-8 bg-gradient-to-r from-blue-50 to-purple-50 rounded-xl p-6">
        <h4 className="font-semibold text-gray-900 mb-3">What you can do with PDF Reader AI:</h4>
        <ul className="space-y-2 text-sm text-gray-700">
          <li className="flex items-center space-x-2">
            <div className="w-2 h-2 bg-blue-600 rounded-full"></div>
            <span>Extract and analyze text from any PDF document</span>
          </li>
          <li className="flex items-center space-x-2">
            <div className="w-2 h-2 bg-purple-600 rounded-full"></div>
            <span>Generate intelligent summaries and key insights</span>
          </li>
          <li className="flex items-center space-x-2">
            <div className="w-2 h-2 bg-pink-600 rounded-full"></div>
            <span>Ask questions about the document content</span>
          </li>
          <li className="flex items-center space-x-2">
            <div className="w-2 h-2 bg-indigo-600 rounded-full"></div>
            <span>Get explanations for complex topics</span>
          </li>
        </ul>
      </div>
    </div>
  );
};

export default FileUpload;
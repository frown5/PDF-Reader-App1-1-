import React, { useState, useRef, useEffect } from 'react';
import { 
  Bot, 
  Send, 
  User, 
  Sparkles, 
  FileText, 
  MessageSquare, 
  Lightbulb,
  X,
  Copy,
  Check
} from 'lucide-react';

interface Message {
  id: string;
  type: 'user' | 'assistant';
  content: string;
  timestamp: Date;
}

interface AIAssistantProps {
  extractedText: string;
  fileName: string;
  onClose: () => void;
}

const AIAssistant: React.FC<AIAssistantProps> = ({ 
  extractedText, 
  fileName, 
  onClose 
}) => {
  const [messages, setMessages] = useState<Message[]>([]);
  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [copiedId, setCopiedId] = useState<string | null>(null);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const quickActions = [
    {
      icon: FileText,
      label: 'Summarize',
      prompt: 'Please provide a comprehensive summary of this document, highlighting the main points and key insights.',
      color: 'bg-blue-100 text-blue-700 hover:bg-blue-200'
    },
    {
      icon: Lightbulb,
      label: 'Key Points',
      prompt: 'Extract the most important key points and takeaways from this document.',
      color: 'bg-yellow-100 text-yellow-700 hover:bg-yellow-200'
    },
    {
      icon: MessageSquare,
      label: 'Ask Questions',
      prompt: 'What are some interesting questions I could ask about this document?',
      color: 'bg-green-100 text-green-700 hover:bg-green-200'
    }
  ];

  const simulateAIResponse = async (userMessage: string): Promise<string> => {
    // Simulate API delay
    await new Promise(resolve => setTimeout(resolve, 1000 + Math.random() * 2000));
    
    const prompt = userMessage.toLowerCase();
    
    if (prompt.includes('summarize') || prompt.includes('summary')) {
      return `Based on the document "${fileName}", here's a comprehensive summary:\n\nThis document appears to contain ${Math.floor(extractedText.length / 100)} main sections with key information about the topic. The content covers various aspects and provides detailed insights.\n\n**Key Themes:**\n• Primary concepts and definitions\n• Supporting evidence and examples\n• Conclusions and recommendations\n\n**Main Takeaways:**\n• The document provides valuable insights into the subject matter\n• Multiple perspectives are presented with supporting data\n• Clear connections are made between different concepts\n\nThe document is well-structured and provides a comprehensive overview of the topic with actionable insights.`;
    }
    
    if (prompt.includes('key points') || prompt.includes('important')) {
      return `Here are the key points extracted from "${fileName}":\n\n**Primary Points:**\n• Main concept #1: Core foundation of the document\n• Main concept #2: Supporting framework and methodology\n• Main concept #3: Practical applications and examples\n\n**Secondary Points:**\n• Supporting evidence and data\n• Case studies and real-world examples\n• Future implications and recommendations\n\n**Critical Insights:**\n• The document emphasizes the importance of understanding the fundamentals\n• Multiple approaches are discussed with their respective benefits\n• Clear action items are provided for implementation\n\nThese points represent the core value proposition of the document and should be considered when applying the concepts discussed.`;
    }
    
    if (prompt.includes('question')) {
      return `Here are some thoughtful questions you could explore about "${fileName}":\n\n**Analytical Questions:**\n• What are the main arguments presented in this document?\n• How do the different sections relate to each other?\n• What evidence supports the key claims made?\n\n**Application Questions:**\n• How can these concepts be applied in practice?\n• What are the potential challenges in implementation?\n• What resources would be needed to apply these ideas?\n\n**Critical Questions:**\n• What assumptions does the document make?\n• Are there alternative perspectives to consider?\n• What are the limitations of the approach discussed?\n\n**Future-Oriented Questions:**\n• What are the long-term implications of these ideas?\n• How might these concepts evolve over time?\n• What additional research or development is needed?\n\nThese questions can help you engage more deeply with the document's content and develop a comprehensive understanding of the material.`;
    }
    
    return `I'd be happy to help you understand "${fileName}" better! Based on the document content, I can provide insights, answer specific questions, or help you explore particular aspects of the material.\n\nThe document contains ${extractedText.length} characters of text with rich content that we can analyze together. Feel free to ask me about:\n\n• Specific concepts or terms mentioned\n• Relationships between different ideas\n• Practical applications of the content\n• Clarification of complex topics\n• Comparisons with related concepts\n\nWhat specific aspect would you like to explore?`;
  };

  const handleSendMessage = async () => {
    if (!input.trim() || isLoading) return;

    const userMessage: Message = {
      id: Date.now().toString(),
      type: 'user',
      content: input,
      timestamp: new Date()
    };

    setMessages(prev => [...prev, userMessage]);
    setInput('');
    setIsLoading(true);

    try {
      const response = await simulateAIResponse(input);
      
      const assistantMessage: Message = {
        id: (Date.now() + 1).toString(),
        type: 'assistant',
        content: response,
        timestamp: new Date()
      };

      setMessages(prev => [...prev, assistantMessage]);
    } catch (error) {
      console.error('Error getting AI response:', error);
      const errorMessage: Message = {
        id: (Date.now() + 1).toString(),
        type: 'assistant',
        content: 'I apologize, but I encountered an error processing your request. Please try again.',
        timestamp: new Date()
      };
      setMessages(prev => [...prev, errorMessage]);
    } finally {
      setIsLoading(false);
    }
  };

  const handleQuickAction = (prompt: string) => {
    setInput(prompt);
    handleSendMessage();
  };

  const copyToClipboard = async (text: string, messageId: string) => {
    try {
      await navigator.clipboard.writeText(text);
      setCopiedId(messageId);
      setTimeout(() => setCopiedId(null), 2000);
    } catch (error) {
      console.error('Failed to copy text:', error);
    }
  };

  return (
    <div className="h-full flex flex-col bg-white">
      {/* Header */}
      <div className="flex items-center justify-between p-4 border-b bg-gradient-to-r from-purple-600 to-pink-600 text-white">
        <div className="flex items-center space-x-3">
          <div className="bg-white/20 p-2 rounded-full">
            <Bot className="h-5 w-5" />
          </div>
          <div>
            <h3 className="font-semibold">AI Assistant</h3>
            <p className="text-sm text-purple-100">Ask me anything about your PDF</p>
          </div>
        </div>
        <button
          onClick={onClose}
          className="p-2 hover:bg-white/20 rounded-lg transition-colors"
        >
          <X className="h-5 w-5" />
        </button>
      </div>

      {/* Messages */}
      <div className="flex-1 overflow-y-auto p-4 space-y-4">
        {messages.length === 0 && (
          <div className="text-center py-8">
            <div className="bg-gradient-to-r from-purple-100 to-pink-100 p-6 rounded-xl">
              <Sparkles className="h-12 w-12 text-purple-600 mx-auto mb-4" />
              <h4 className="font-semibold text-gray-900 mb-2">Welcome to AI Assistant</h4>
              <p className="text-gray-600 text-sm mb-4">
                I can help you analyze, summarize, and understand your PDF document.
              </p>
              <div className="grid grid-cols-1 gap-2">
                {quickActions.map((action, index) => (
                  <button
                    key={index}
                    onClick={() => handleQuickAction(action.prompt)}
                    className={`flex items-center space-x-2 p-3 rounded-lg transition-colors ${action.color}`}
                  >
                    <action.icon className="h-4 w-4" />
                    <span className="text-sm font-medium">{action.label}</span>
                  </button>
                ))}
              </div>
            </div>
          </div>
        )}

        {messages.map((message) => (
          <div
            key={message.id}
            className={`flex ${message.type === 'user' ? 'justify-end' : 'justify-start'}`}
          >
            <div
              className={`max-w-[85%] rounded-2xl p-4 ${
                message.type === 'user'
                  ? 'bg-blue-600 text-white'
                  : 'bg-gray-100 text-gray-900'
              }`}
            >
              <div className="flex items-start space-x-3">
                {message.type === 'assistant' && (
                  <div className="bg-gradient-to-r from-purple-600 to-pink-600 p-1.5 rounded-full flex-shrink-0">
                    <Bot className="h-4 w-4 text-white" />
                  </div>
                )}
                <div className="flex-1">
                  <div className="whitespace-pre-wrap text-sm leading-relaxed">
                    {message.content}
                  </div>
                  <div className="flex items-center justify-between mt-2">
                    <div className={`text-xs ${
                      message.type === 'user' ? 'text-blue-100' : 'text-gray-500'
                    }`}>
                      {message.timestamp.toLocaleTimeString()}
                    </div>
                    {message.type === 'assistant' && (
                      <button
                        onClick={() => copyToClipboard(message.content, message.id)}
                        className="p-1 hover:bg-gray-200 rounded transition-colors"
                      >
                        {copiedId === message.id ? (
                          <Check className="h-3 w-3 text-green-600" />
                        ) : (
                          <Copy className="h-3 w-3 text-gray-500" />
                        )}
                      </button>
                    )}
                  </div>
                </div>
                {message.type === 'user' && (
                  <div className="bg-white/20 p-1.5 rounded-full flex-shrink-0">
                    <User className="h-4 w-4 text-white" />
                  </div>
                )}
              </div>
            </div>
          </div>
        ))}

        {isLoading && (
          <div className="flex justify-start">
            <div className="bg-gray-100 rounded-2xl p-4 max-w-[85%]">
              <div className="flex items-center space-x-3">
                <div className="bg-gradient-to-r from-purple-600 to-pink-600 p-1.5 rounded-full">
                  <Bot className="h-4 w-4 text-white" />
                </div>
                <div className="flex space-x-1">
                  <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce"></div>
                  <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce" style={{ animationDelay: '0.1s' }}></div>
                  <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce" style={{ animationDelay: '0.2s' }}></div>
                </div>
              </div>
            </div>
          </div>
        )}
        
        <div ref={messagesEndRef} />
      </div>

      {/* Input */}
      <div className="p-4 border-t bg-gray-50">
        <div className="flex items-center space-x-2">
          <div className="flex-1 relative">
            <input
              type="text"
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyPress={(e) => e.key === 'Enter' && handleSendMessage()}
              placeholder="Ask me anything about your PDF..."
              className="w-full px-4 py-3 rounded-xl border border-gray-200 focus:outline-none focus:ring-2 focus:ring-purple-500 focus:border-transparent pr-12"
              disabled={isLoading}
            />
            <button
              onClick={handleSendMessage}
              disabled={!input.trim() || isLoading}
              className="absolute right-2 top-1/2 transform -translate-y-1/2 bg-gradient-to-r from-purple-600 to-pink-600 text-white p-2 rounded-lg hover:from-purple-700 hover:to-pink-700 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
            >
              <Send className="h-4 w-4" />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default AIAssistant;
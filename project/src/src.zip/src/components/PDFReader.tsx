import React, { useState, useCallback } from 'react';
import { Document, Page, pdfjs } from 'react-pdf';
import { 
  FileText, 
  Upload, 
  ZoomIn, 
  ZoomOut, 
  ChevronLeft, 
  ChevronRight,
  Bot,
  MessageCircle,
  FileCheck,
  Sparkles,
  X,
  Download
} from 'lucide-react';
import FileUpload from './FileUpload';
import AIAssistant from './AIAssistant';
import 'react-pdf/dist/esm/Page/AnnotationLayer.css';
import 'react-pdf/dist/esm/Page/TextLayer.css';

// Configure PDF.js worker
// pdfjs.GlobalWorkerOptions.workerSrc = `//unpkg.com/pdfjs-dist@${pdfjs.version}/build/pdf.worker.min.js`;
pdfjs.GlobalWorkerOptions.workerSrc ='/pdf.worker.min.mjs';

interface PDFReaderProps {}

const PDFReader: React.FC<PDFReaderProps> = () => {
  const [file, setFile] = useState<File | null>(null);
  const [numPages, setNumPages] = useState<number | null>(null);
  const [pageNumber, setPageNumber] = useState(1);
  const [scale, setScale] = useState(1.0);
  const [extractedText, setExtractedText] = useState<string>('');
  const [loading, setLoading] = useState(false);
  const [showAI, setShowAI] = useState(false);
  const [pdfUrl, setPdfUrl] = useState<string | null>(null);

  const onFileSelect = useCallback((selectedFile: File) => {
    setFile(selectedFile);
    setPageNumber(1);
    setExtractedText('');
    
    // Create URL for the PDF
    const url = URL.createObjectURL(selectedFile);
    setPdfUrl(url);
  }, []);

  const onDocumentLoadSuccess = useCallback(({ numPages }: { numPages: number }) => {
    setNumPages(numPages);
    setLoading(false);
  }, []);

  const onDocumentLoadError = useCallback((error: Error) => {
    console.error('Error loading PDF:', error);
    setLoading(false);
  }, []);

  const extractTextFromPDF = useCallback(async () => {
    if (!file) return;
    
    setLoading(true);
    try {
      const arrayBuffer = await file.arrayBuffer();
      const pdf = await pdfjs.getDocument({ data: arrayBuffer }).promise;
      let fullText = '';
      
      for (let i = 1; i <= pdf.numPages; i++) {
        const page = await pdf.getPage(i);
        const textContent = await page.getTextContent();
        const pageText = textContent.items
          .map((item: any) => item.str)
          .join(' ');
        fullText += pageText + '\n\n';
      }
      
      setExtractedText(fullText);
    } catch (error) {
      console.error('Error extracting text:', error);
    } finally {
      setLoading(false);
    }
  }, [file]);

  const goToPrevPage = () => {
    setPageNumber(prev => Math.max(1, prev - 1));
  };

  const goToNextPage = () => {
    setPageNumber(prev => Math.min(numPages || 1, prev + 1));
  };

  const zoomIn = () => {
    setScale(prev => Math.min(2.0, prev + 0.2));
  };

  const zoomOut = () => {
    setScale(prev => Math.max(0.5, prev - 0.2));
  };

  const removePDF = () => {
    setFile(null);
    setPdfUrl(null);
    setNumPages(null);
    setPageNumber(1);
    setExtractedText('');
    setShowAI(false);
    if (pdfUrl) {
      URL.revokeObjectURL(pdfUrl);
    }
  };

  return (
    <div className="flex h-screen bg-gray-50">
      {/* Main Content */}
      <div className="flex-1 flex flex-col">
        {/* Header */}
        <header className="bg-white shadow-sm border-b px-6 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <FileText className="h-8 w-8 text-blue-600" />
              <h1 className="text-2xl font-bold text-gray-900">PDF Reader AI</h1>
            </div>
            
            {file && (
              <div className="flex items-center space-x-4">
                <span className="text-sm text-gray-600 bg-gray-100 px-3 py-1 rounded-full">
                  {file.name}
                </span>
                <button
                  onClick={removePDF}
                  className="p-2 text-gray-500 hover:text-red-600 hover:bg-red-50 rounded-lg transition-colors"
                  title="Remove PDF"
                >
                  <X className="h-5 w-5" />
                </button>
              </div>
            )}
          </div>
        </header>

        {/* Content */}
        <div className="flex-1 flex">
          {/* PDF Viewer */}
          <div className="flex-1 flex flex-col">
            {!file ? (
              <div className="flex-1 flex items-center justify-center">
                <FileUpload onFileSelect={onFileSelect} />
              </div>
            ) : (
              <>
                {/* Toolbar */}
                <div className="bg-white border-b px-6 py-3 flex items-center justify-between">
                  <div className="flex items-center space-x-4">
                    <button
                      onClick={goToPrevPage}
                      disabled={pageNumber <= 1}
                      className="p-2 rounded-lg border hover:bg-gray-50 disabled:opacity-50 disabled:cursor-not-allowed"
                    >
                      <ChevronLeft className="h-5 w-5" />
                    </button>
                    
                    <span className="text-sm font-medium text-gray-700">
                      Page {pageNumber} of {numPages || 0}
                    </span>
                    
                    <button
                      onClick={goToNextPage}
                      disabled={pageNumber >= (numPages || 0)}
                      className="p-2 rounded-lg border hover:bg-gray-50 disabled:opacity-50 disabled:cursor-not-allowed"
                    >
                      <ChevronRight className="h-5 w-5" />
                    </button>
                  </div>
                  
                  <div className="flex items-center space-x-2">
                    <button
                      onClick={zoomOut}
                      className="p-2 rounded-lg border hover:bg-gray-50"
                    >
                      <ZoomOut className="h-5 w-5" />
                    </button>
                    
                    <span className="text-sm font-medium text-gray-700 min-w-[60px] text-center">
                      {Math.round(scale * 100)}%
                    </span>
                    
                    <button
                      onClick={zoomIn}
                      className="p-2 rounded-lg border hover:bg-gray-50"
                    >
                      <ZoomIn className="h-5 w-5" />
                    </button>
                  </div>
                </div>

                {/* PDF Display */}
                <div className="flex-1 overflow-auto bg-gray-100 p-6">
                  <div className="flex justify-center">
                    <div className="bg-white shadow-lg rounded-lg overflow-hidden">
                      {loading && (
                        <div className="flex items-center justify-center h-96">
                          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div>
                        </div>
                      )}
                      
                      {pdfUrl && (
                        <Document
                          file={pdfUrl}
                          onLoadSuccess={onDocumentLoadSuccess}
                          onLoadError={onDocumentLoadError}
                          loading={
                            <div className="flex items-center justify-center h-96">
                              <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div>
                            </div>
                          }
                        >
                          <Page
                            pageNumber={pageNumber}
                            scale={scale}
                            renderTextLayer={true}
                            renderAnnotationLayer={true}
                          />
                        </Document>
                      )}
                    </div>
                  </div>
                </div>
              </>
            )}
          </div>

          {/* AI Assistant Panel */}
          {showAI && (
            <div className="w-96 border-l bg-white">
              <AIAssistant
                extractedText={extractedText}
                fileName={file?.name || ''}
                onClose={() => setShowAI(false)}
              />
            </div>
          )}
        </div>

        {/* AI Actions Bar */}
        {file && (
          <div className="bg-white border-t px-6 py-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-4">
                <button
                  onClick={extractTextFromPDF}
                  disabled={loading}
                  className="flex items-center space-x-2 bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 transition-colors disabled:opacity-50"
                >
                  <FileCheck className="h-5 w-5" />
                  <span>Extract Text</span>
                </button>
                
                <button
                  onClick={() => setShowAI(true)}
                  disabled={!extractedText}
                  className="flex items-center space-x-2 bg-gradient-to-r from-purple-600 to-pink-600 text-white px-4 py-2 rounded-lg hover:from-purple-700 hover:to-pink-700 transition-colors disabled:opacity-50"
                >
                  <Bot className="h-5 w-5" />
                  <span>AI Assistant</span>
                </button>
              </div>
              
              {extractedText && (
                <div className="flex items-center space-x-2 text-sm text-gray-600">
                  <Sparkles className="h-4 w-4" />
                  <span>Text extracted • {extractedText.length} characters</span>
                </div>
              )}
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default PDFReader;
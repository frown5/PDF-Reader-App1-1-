/// <reference types="vite/client" />
optimizeDeps: {
  include: ['pdfjs-dist/build/pdf.worker.entry']
}